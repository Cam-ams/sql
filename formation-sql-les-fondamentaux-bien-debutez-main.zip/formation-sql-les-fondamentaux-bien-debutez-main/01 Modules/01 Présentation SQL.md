# Module 01 - Présentation SQL
<a href="../00 Les fichiers PDF - Supports de cours/01 Présentation SQL.pdf">
  <img src="../img/mod/m1.webp" width="300">
</a>  
<br>
<a href="../00 Les fichiers PDF - Supports de cours/01 Présentation SQL.pdf">
Le PDF : 01 Présentation SQL
</a>  




## heidi SQL
<a href="https://www.heidisql.com/download.php">
  <img src="../img/screen/heidi.webp" width="500">
  </a>
  <br>
 <a href="https://www.heidisql.com/download.php">https://www.heidisql.com/download.php</a>

## Laragon
Pour installer mysql 
avec phpMyAdmin
<br>
<a href="https://laragon.org/">
  <img src="../img/screen/laragon.webp" width="500">
  </a>
  <br>
 <a href="https://laragon.org/">https://laragon.org/</a>

## Workbench

<br>
<a href="https://dev.mysql.com/downloads/workbench/">
  <img src="../img/screen/workbench.png" width="500">
  </a>
  <br>
 <a href="https://dev.mysql.com/downloads/workbench/">Workbench</a>

## SQL Server & SSMS
SQL Server & **S**erver **M**anagement **S**tudio (SSMS)
<br>
<a href="https://www.microsoft.com/fr-fr/sql-server/sql-server-downloads">
  <img src="../img/screen/sql-server.webp" width="400">
  </a>

 <a href="https://www.microsoft.com/fr-fr/sql-server/sql-server-downloads">https://www.microsoft.com/fr-fr/sql-server/sql-server-downloads</a>
<br>
Cliquez sur le bouton Installer SSMS à la dernière étape de l'assistant d'installation de SQL Server  
Une page Web s'ouvre avec un lien pour télécharger SQL Server Management Studio.


## Une documentation bien utile !
https://www.w3schools.com/mysql/default.asp  
https://sql.sh/  
https://dev.mysql.com/doc/refman/8.4/en/select.html  
[Tuto Learn sql](https://learnsql.fr/blog/20-exemples-de-requetes-sql-de-base-pour-les-debutants-une-vue-d-ensemble-complete/)  