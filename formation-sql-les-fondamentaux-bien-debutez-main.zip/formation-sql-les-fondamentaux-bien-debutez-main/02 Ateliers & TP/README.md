
|TP| Bonus | Difficultés | Module|
|---|---|---|---|
|TP 01 Le monde des chats | | | Module **02** Ma première Base de données|
|TP 02 Vip Cocktail|$\color{red}{\text{[BONUS]}}$ |:cactus:| Module **02** Ma première Base de données|
|TP 03 Le monde des chats **partie 2** | | |Module **04** Extraire les données|
|TP 04 Vip Cocktail **partie 2** |$\color{red}{\text{[BONUS]}}$ || Module **04** Extraire les données|
|TP 05 Le monde des chats **partie 3** | |:cactus:| Module **06** Les jointures|
|TP 06 Les films avec catégories|$\color{red}{\text{[BONUS]}}$ |:cactus:| Module **06** Les jointures|
|TP 07 Le CRM Devis & Facture| |:cactus::cactus::cactus:|Module **07** Mise en place de plusieurs jointures|
|TP 08 film avec acteurs| |:cactus:|Module **08** La table de jointures|
|TP 09 Site E-commerce|$\color{red}{\text{[BONUS]}}$ |:cactus:|Module **08** La table de jointures|
|TP 10 Location ski|$\color{red}{\text{[SUPER BONUS]}}$ |:cactus::cactus::cactus::cactus:|Module **08** La table de jointures|